package cz.muni.fi.pb162.project.geometry;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;



/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public final class LabeledPolygon extends SimplePolygon implements Labelable, Sortable, PolygonWritable{

    private Map<String, Vertex2D> vertices;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private LabeledPolygon(Map<String, Vertex2D> vertices){

        super(vertices.values().toArray(new Vertex2D[0]));
        this.vertices = vertices;
    }

    @Override
    public Vertex2D getVertex(String label) {
        if(!vertices.containsKey(label)){
            throw new IllegalArgumentException();

        }

           return vertices.get(label);

    }

    @Override
    public Collection<String> getLabels() {

        return Collections.unmodifiableSet(vertices.keySet());
    }

    @Override
    public Collection<String> getLabels(Vertex2D vertex) {
        return vertices.entrySet().stream()
                .filter(entry -> entry.getValue().equals(vertex)).map(Map.Entry :: getKey)
                .collect(Collectors.toSet());
    }

    @Override
    public Vertex2D getVertex(int index) {
        if(index < 0){
            throw new IllegalArgumentException("index is a negative number");
        }


        return new ArrayList<>(vertices.values()).get(index% vertices.size());
    }

    @Override
    public int getNumVertices() {

        return vertices.size();
    }

    @Override
    public Collection<Vertex2D> getSortedVertices() {
        return new TreeSet<>(vertices.values());
    }

    @Override
    public Collection<Vertex2D> getSortedVertices(Comparator<Vertex2D> comparator) {
        Set<Vertex2D> sorted = new TreeSet<>(comparator);
        sorted.addAll(vertices.values());
        return sorted;
    }

    /**
     *
     * @return duplicate coordinates
     */
    public Collection<Vertex2D> duplicateVertices(){
        ArrayList<Vertex2D> duplicates = new ArrayList<>();

        for (Vertex2D coordinate : vertices.values()){
            if(Collections.frequency(vertices.values(),coordinate)>1){
                duplicates.add(coordinate);
            }
        }
        return new HashSet<>(duplicates);
    }

    @Override
    public void write(OutputStream os) throws IOException {

        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));

        for (Map.Entry<String, Vertex2D> entry : vertices.entrySet()) {
            bw.write(entry.getValue().getX() +" " + entry.getValue().getY() +" "+ entry.getKey());
            bw.newLine();
        }
        bw.flush();
    }

    @Override
    public void write(File file) throws IOException {

        try(OutputStream os = new FileOutputStream(file)){
            write(os);
        }

    }

    /**
     *
     * @param os out put stream
     * @throws IOException when things go wrong
     */
    public void writeJson(OutputStream os) throws IOException{
        Writer w = new OutputStreamWriter(os);
        w.write(GSON.toJson(vertices));
        w.flush();
    }

    /**
     * TODO : create javadoc
     *
     * @author Ema Stefanikova
     */
    public static class Builder implements Buildable<LabeledPolygon>, PolygonReadable{

        private Map<String, Vertex2D> vertices = new TreeMap<>();

        /**
         *Adds vertex
         * @param label - name of coordinate
         * @param vertex - coordinate
         * @return this
         */
        public Builder addVertex(String label, Vertex2D vertex) {
            if(label == null || vertex ==null){
                throw new IllegalArgumentException("label or vertex are null");
            }
            vertices.put(label, vertex);
            return this;
        }
        @Override
        public LabeledPolygon build() {

            return new LabeledPolygon(vertices);
        }

        @Override
        public Builder read(InputStream is) throws IOException {

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(is, StandardCharsets.UTF_8)
            );

            Map<String, Vertex2D> tryVertices = new TreeMap<>();

            while(br.ready()){
                String[] data = br.readLine().split(" ",3);

                try {
                    if (data.length == 3){
                        tryVertices.put(data[2], new Vertex2D(Double.valueOf(data[0]), Double.valueOf(data[1])));
                    } else {
                        throw new IOException("error");
                    }
                } catch(NumberFormatException e) {
                    throw new IOException("Bad format");
                }
            }

            vertices.putAll(tryVertices);

            return this;
        }




        @Override
        public Builder read(File file) throws IOException {
            try (InputStream is = new FileInputStream(file)) {
                read(is);
            }

            return this;
        }
    }
}
