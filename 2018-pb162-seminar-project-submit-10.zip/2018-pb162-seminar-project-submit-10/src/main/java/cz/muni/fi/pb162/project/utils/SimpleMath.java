package cz.muni.fi.pb162.project.utils;
import cz.muni.fi.pb162.project.geometry.Polygon;



/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class SimpleMath {

    /**
     *
     * @param polygon - in which is being searched the smallest X
     * @return the smallest coordinate X of polygon coordinates
     */
    public static double minX(Polygon polygon) {
        double x = polygon.getVertex(0).getX();

        for (int coordinates = 1; coordinates < polygon.getNumVertices(); coordinates++) {
            if (polygon.getVertex(coordinates).getX() <= x){
                x = polygon.getVertex(coordinates).getX() ;
            }
        }
        return x;
    }

    /**
     *
     * @param polygon - in which is being searched the smallest Y
     * @return the smallest coordinate Y of triangle coordinates
     */
    public static double minY (Polygon polygon) {
            double y = polygon.getVertex(0).getY();

                for (int coordinates = 1; coordinates < polygon.getNumVertices(); coordinates++) {
                    if (polygon.getVertex(coordinates).getY() <= y){
                        y = polygon.getVertex(coordinates).getY() ;
                    }
                }
                return y;
        }

    /**
     *
     * @param polygon - in which is being searched the largest X
     * @return the largest coordinate X of triangle coordinates
     */
    public static double maxX(Polygon polygon){
             double x = polygon.getVertex(0).getX();

             for (int coordinates = 1; coordinates < polygon.getNumVertices(); coordinates++) {
                 if (polygon.getVertex(coordinates).getX() >= x){
                     x = polygon.getVertex(coordinates).getX() ;
                 }
             }
             return x;
         }

    /**
     *
     * @param polygon - in which is being searched the largest Y
     * @return the largest coordinate y of triangle coordinates
     */
    public static double maxY(Polygon polygon) {
             double y = polygon.getVertex(0).getY();

             for (int coordinates = 1; coordinates < polygon.getNumVertices(); coordinates++) {
                 if (polygon.getVertex(coordinates).getY() >= y){
                     y = polygon.getVertex(coordinates).getY() ;
                 }
             }
             return y;
         }
    }

