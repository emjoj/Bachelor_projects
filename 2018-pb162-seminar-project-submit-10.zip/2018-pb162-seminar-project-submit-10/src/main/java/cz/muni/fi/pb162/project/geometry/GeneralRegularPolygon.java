package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class GeneralRegularPolygon implements RegularPolygon, Colored {

    private int numberOfEdges;
    private double radius;
    private Color color = Color.BLACK;
    private Vertex2D center;

    /**
     *
     * @param center Vertex of polygon
     * @param numberOfEdges number of coordinates
     * @param radius diameter/2
     */
    public GeneralRegularPolygon(Vertex2D center, int numberOfEdges, double radius){
        this.numberOfEdges = numberOfEdges;
        this.center = center;
        this.radius = radius;

    }

    public int getNumEdges(){
        return numberOfEdges;
    }

    public double getEdgeLength(){
        return 2*radius*Math.sin(Math.PI/numberOfEdges);
    }

    /**
     *
     * @param index integral number of index
     * @return new coordinates
     */
    public Vertex2D getVertex(int index){

        double x = center.getX() - radius * Math.cos(index * 2 * (Math.PI/numberOfEdges));
        double y = center.getY() - radius * Math.sin(index * 2 * (Math.PI/numberOfEdges));

        return new Vertex2D(x,y);
    }

    public double getWidth() {
        return 2*radius;
    }


    public double getHeight() {
        return 2*radius;
    }

    /**
     *
     * @return information about polygon
     */
    public String toString(){
        return numberOfEdges + "-gon: center=" + center + ", radius=" + radius + ", color="+color;

    }

    public Vertex2D getCenter(){
        return center;
    }

    public double getRadius(){
        return radius;
    }
    public Color getColor(){
        return color;
    }

    public void setColor(Color color){
        this.color = color;

    }

}
