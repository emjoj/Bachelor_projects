package cz.muni.fi.pb162.project.geometry;


/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Snowman {

    private static final double DEFAULT_F = 0.8;
    private static  final int NUMBER_OF_BALLS = 3;
    private RegularPolygon[] snowBall = new RegularPolygon[3];

    /**
     *
     * @param regularPolygon represents the first ball of snowman
     * @param f represents a decreasing factor of radius size
     */
    public Snowman(RegularPolygon regularPolygon, double f){
        if (f <= 0 || f > 1){
            f = DEFAULT_F;
        }

        snowBall[0] = new GeneralRegularPolygon(regularPolygon.getCenter(),
                regularPolygon.getNumEdges(),regularPolygon.getRadius());

        for(int i = 1; i < NUMBER_OF_BALLS; i ++){
            snowBall[i] = new GeneralRegularPolygon(new Vertex2D(regularPolygon.getCenter().getX(),
                    snowBall[i-1].getCenter().getY() + (snowBall[i-1].getRadius()+ (snowBall[i-1].getRadius()* f))),
                    regularPolygon.getNumEdges(),snowBall[i-1].getRadius()*f);
        }
    }

    public RegularPolygon[] getBalls(){
        return this.snowBall;
    }

}
