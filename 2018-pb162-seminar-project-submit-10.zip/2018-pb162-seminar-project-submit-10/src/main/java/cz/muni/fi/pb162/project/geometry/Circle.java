package cz.muni.fi.pb162.project.geometry;

import static cz.muni.fi.pb162.project.geometry.Color.RED;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Circle  extends GeneralRegularPolygon implements Measurable, Circumcircle {

        /**
         * @param center coordinates of circle center
         * @param radius of circle
         */

        public Circle(Vertex2D center, double radius) {

            super(center,Integer.MAX_VALUE,radius);
            super.setColor(RED);

        }

        /**
         * this call previous constructor and set values
         */
        public Circle() {
            this(new Vertex2D(0, 0), 1);
        }

        public double getEdgeLength(){
            return 0;
        }


        @Override
        public String toString() {
            return "Circle: center=" + super.getCenter() + ", radius=" + super.getRadius();
        }




}

