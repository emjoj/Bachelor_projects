package cz.muni.fi.pb162.project.geometry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static cz.muni.fi.pb162.project.utils.SimpleMath.minX;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */


public class CollectionPolygon extends SimplePolygon {

    private List<Vertex2D> coordinates ;

    /**
     *
     * @param coordinates input coordinates of polygon
     */
    public CollectionPolygon(Vertex2D[] coordinates){
        super(coordinates);
        this.coordinates = new ArrayList<>(Arrays.asList(coordinates));
    }

    /**
     *
     * @param coordinates input coordinates of polygon
     */
    public CollectionPolygon(List<Vertex2D> coordinates){
        super(coordinates.toArray(new Vertex2D[0]));
        this.coordinates = new ArrayList<>(coordinates);
        
    }

    /**
     *
     * @return new polygon without the most left vertices
     */
    public CollectionPolygon withoutLeftmostVertices(){
        double leftX = minX(this);


        List<Vertex2D> withoutLeftmostVertices = new ArrayList<>();

        if (coordinates.isEmpty()){
            throw new IllegalArgumentException("error");
        }

        for (Vertex2D c: this.coordinates) {

            if(c.getX() != leftX){

                withoutLeftmostVertices.add(c);
            }
        }
        return new CollectionPolygon(withoutLeftmostVertices);
    }

    /**
     *
     * @param index vertex index, not negative number
     * @return wanted vertex
     */
    public Vertex2D getVertex(int index){

        if(coordinates.size() == 0){
            throw new java.lang.IllegalArgumentException("empty");
        }else if( (index > coordinates.size())|| ( index < 0 ) ){
            throw new java.lang.IllegalArgumentException("index");
        }

        return coordinates.get(index % coordinates.size());


    }

    public int getNumVertices(){

        return coordinates.size();

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CollectionPolygon that = (CollectionPolygon) o;
        return Objects.equals(coordinates, that.coordinates);
    }

    @Override
    public int hashCode() {
        return Objects.hash(coordinates);
    }
}
