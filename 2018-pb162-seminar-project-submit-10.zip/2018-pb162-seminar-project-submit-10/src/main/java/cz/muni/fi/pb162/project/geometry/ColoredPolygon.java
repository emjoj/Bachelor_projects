package cz.muni.fi.pb162.project.geometry;

import java.util.Objects;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class ColoredPolygon {

    private Color color;
    private Polygon polygon;

    /**
     * constructor set attributes
     * @param polygon input polygon
     * @param color input color
     */
    public ColoredPolygon(Polygon polygon, Color color){
        this.color = color;
        this.polygon = polygon;



    }


    public Polygon getPolygon(){
    return this.polygon;

    }

    public Color getColor(){

    return this.color;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ColoredPolygon that = (ColoredPolygon) o;
        return color == that.color &&
                Objects.equals(polygon, that.polygon);
    }

    @Override
    public int hashCode() {
        return Objects.hash(color, polygon);
    }
}