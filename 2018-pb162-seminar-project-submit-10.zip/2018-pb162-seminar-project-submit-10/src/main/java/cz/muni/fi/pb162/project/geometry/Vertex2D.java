package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Vertex2D implements Comparable<Vertex2D> {


    private final double x;
    private final double y;

    /**
     * constructor of Vertex2D
     *
     * @param x an arugument
     * @param y another argument.
     */

    public Vertex2D(double x, double y) {
        this.x = x;
        this.y = y;

    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    /**
     * @return info about coordinates.
     */
    @Override
    public String toString() {

        return "[" + x + ", " + y + "]";
    }

    /**
     *
     * @param vertex input coordinates
     * @return Euclidean distance of input coordinates
     */
    public double distance(Vertex2D vertex) {
        if (vertex == null) {
            return -1;
        }

        return java.lang.Math.hypot(vertex.x - x, vertex.y - y);
    }

    /**
     * creates a new coordinate in the middle of two coordinates
     *
     * @param otherVertex represent used coordinate in the calculation
     * @return new coordinate made from 2 input oordinates
     */

    public Vertex2D createMiddle(Vertex2D otherVertex) {

        return new Vertex2D((this.x + otherVertex.x) / 2, (this.y + otherVertex.y) / 2);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) {
            return false;
        }
        if (this.getClass() != o.getClass()) {
            return false;
        }
        Vertex2D other = (Vertex2D) o;

        return Double.compare(this.x, other.x) == 0
                && Double.compare(this.y,other.y) == 0;
    }
    @Override
    public int hashCode(){
        int result = 13;

        result = result *17 + (int) (Double.doubleToLongBits(x));
        result = result *23 + (int) (Double.doubleToLongBits(y));
        return  result;
    }

    @Override
    public int compareTo(Vertex2D o) {

        //ak true vrati co je za ? ak false vrati co je za :

        int diffX =  Double.compare(this.getX(),o.getX());
        return diffX != 0 ? diffX : Double.compare(this.y,o.y);
    }


}



