package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class RegularOctagon extends GeneralRegularPolygon{

    /**
     *
     * @param center coordinate of Octagon
     * @param radius diameter/2
     */
    public RegularOctagon(Vertex2D center, double radius){
        super(center,8,radius);


    }
}
