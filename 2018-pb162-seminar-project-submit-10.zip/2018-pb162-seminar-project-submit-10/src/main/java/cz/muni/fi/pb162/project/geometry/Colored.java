package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public interface Colored {
    /**
     *
     * @return method return the color of polygon
     */
    Color getColor();

    /**
     *
     * @param color is being set in the method to object
     */
    void  setColor(Color color);
}
