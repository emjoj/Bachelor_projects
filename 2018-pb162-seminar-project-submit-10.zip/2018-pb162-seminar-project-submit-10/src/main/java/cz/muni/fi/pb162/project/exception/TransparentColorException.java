package cz.muni.fi.pb162.project.exception;



/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class TransparentColorException extends Exception {
    /**
     *
     * @param message with problem
     */
    public TransparentColorException(String message){
        super(message);
    }

    /**
     *
     * @param message with problem
     * @param cause of the problem
     */
    public TransparentColorException(String message, Throwable cause){
        super(message,cause);
    }
}
