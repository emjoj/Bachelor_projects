package cz.muni.fi.pb162.project.geometry;
import java.util.Arrays;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class ArrayPolygon extends SimplePolygon {

    private final Vertex2D[] coordinates;

    /**
     * constructor set copy of input array of coordinates to attribute
     * @param coordinates represents array of polygon coordinates
     */
    public ArrayPolygon(Vertex2D[] coordinates){
        super(coordinates);
        this.coordinates = Arrays.copyOf(coordinates,coordinates.length);


    }


    @Override
    public Vertex2D getVertex(int index) {
        if(index < 0){
            throw new IllegalArgumentException("Input index is out of range");

        }
        return coordinates[index % getNumVertices()];

    }

    @Override
    public int getNumVertices() {
     return coordinates.length;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ArrayPolygon that = (ArrayPolygon) o;
        return Arrays.equals(coordinates, that.coordinates);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(coordinates);
    }
}

