package cz.muni.fi.pb162.project.exception;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class MissingVerticesException extends RuntimeException {

    /**
     *
     * @param message with problem
     */
    public MissingVerticesException(String message){
        super(message);
    }

    /**
     *
     * @param message with problem
     * @param cause of the problem
     */
    public MissingVerticesException(String message, Throwable cause){
        super(message,cause);
    }
}
