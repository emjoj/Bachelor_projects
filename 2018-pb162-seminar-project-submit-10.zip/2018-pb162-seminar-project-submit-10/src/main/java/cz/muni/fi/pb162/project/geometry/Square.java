package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Square extends GeneralRegularPolygon implements Circumcircle{


    /**
     *
     * @param center of Circumscribed circle coordinates
     * @param diameter is 2 * radius
     */
    public Square(Vertex2D center, double diameter) {
        super(center,4,diameter/2);
    }

    /**
     *
     * @param circumcircle is input object to which
     * is set centre coordinates and radius
     */
    public Square(Circumcircle circumcircle) {

        super(circumcircle.getCenter(),4,circumcircle.getRadius());

        }

    /**
     *
     * @return information about square
     */
    public String toString() {
        return "Square: vertices="+ getVertex(0) + " " +
                getVertex(1) + " " + getVertex(2) + " " + getVertex(3);
    }

}
