package cz.muni.fi.pb162.project.utils;

import cz.muni.fi.pb162.project.geometry.Measurable;
import cz.muni.fi.pb162.project.geometry.Triangle;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Gauger {

    /**
     * the first constructor print the width and the height of measurable
     * @param measurable is an input measurable
     */
    public static void printMeasurement(Measurable measurable){

        System.out.println("Width: "+ measurable.getWidth());
        System.out.println("Height: "+ measurable.getHeight());
    }

    /**
     * the second constructor print a triangle information
        and call a previous constructor
     * @param triangle is an input triangle
     */
    public static void printMeasurement (Triangle triangle){

        System.out.println(triangle.toString());
        printMeasurement((Measurable) triangle);
    }
}
