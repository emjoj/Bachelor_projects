package cz.muni.fi.pb162.project.geometry;


import cz.muni.fi.pb162.project.exception.EmptyDrawableException;
import cz.muni.fi.pb162.project.exception.MissingVerticesException;
import cz.muni.fi.pb162.project.exception.TransparentColorException;


import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Paper implements Drawable,PolygonFactory {


    private Color currentColor = Color.BLACK;
    private List<ColoredPolygon> drawnPolygons;



    /**
     * set Arraylist to drawnPolygons
     */
    public Paper(){
        drawnPolygons = new ArrayList<>();
    }

    /**
     * made copy of drawable polygons
     * @param drawable input parameter
     */
    public Paper(Drawable drawable){


        drawnPolygons = new ArrayList<>(drawable.getAllDrawnPolygons());
    }


    @Override
    public void changeColor(Color color) {
        currentColor = color;

    }


    @Override

    public void drawPolygon(Polygon polygon) throws TransparentColorException {


        if(currentColor == Color.WHITE){
            throw new TransparentColorException("Cannot be white");
        }

            if (!(drawnPolygons.contains(new ColoredPolygon(polygon, currentColor)))) {

                drawnPolygons.add(new ColoredPolygon(polygon, currentColor));

            }



    }


    @Override
    public void erasePolygon(ColoredPolygon polygon) {
        drawnPolygons.remove(polygon);

    }

    @Override
    public void eraseAll()throws EmptyDrawableException {
        if(drawnPolygons.size() == 0){
            throw new EmptyDrawableException("empty paper");
        }
        drawnPolygons.clear();

    }

    @Override
    public Collection<ColoredPolygon> getAllDrawnPolygons() {

        return Collections.unmodifiableList(drawnPolygons);
        //important on vnitro
    }

    @Override
    public int uniqueVerticesAmount() {

        Set<Vertex2D> unique = new HashSet<>();
        for ( ColoredPolygon p : drawnPolygons){
            for(int u = 0; u < p.getPolygon().getNumVertices();u++){
                unique.add(p.getPolygon().getVertex(u));
            }
        }

        return unique.size();

    }
    @Override
    public void tryToDrawPolygons(List<List<Vertex2D>> collectionPolygons) throws EmptyDrawableException {
        int polygonsSize = this.getAllDrawnPolygons().size();

        for (Iterator<List<Vertex2D>> polygonIterator = collectionPolygons.iterator(); polygonIterator.hasNext(); ) {
            try {
                drawPolygon(tryToCreatePolygon(polygonIterator.next()));

            } catch (TransparentColorException t) {
                changeColor(Color.BLACK);
            } catch (MissingVerticesException | NullPointerException t) {
                if (!polygonIterator.hasNext() && polygonsSize == this.getAllDrawnPolygons().size()) {
                    throw new EmptyDrawableException("Polygon is not created",t);
                }
            }
        }
    }


        @Override
        public Polygon tryToCreatePolygon(List<Vertex2D> vertices) throws MissingVerticesException{

        if(vertices == null){
            throw new NullPointerException("input vertices are null");
        }
        List<Vertex2D> coordinates = new ArrayList<>(vertices);


        try {
            return new CollectionPolygon(coordinates);
        } catch (IllegalArgumentException e){
            coordinates.removeAll(Collections.singleton(null));
            return new CollectionPolygon(coordinates);
        }

        }

    /**
     *
     * @param color polygon
     * @return drawn polygons
     */
        public Collection<Polygon> getPolygonsWithColor(Color color){
        return drawnPolygons
                .stream()
                .filter(p -> p.getColor() == color).map(ColoredPolygon::getPolygon).collect(Collectors.toList());

        }


}
