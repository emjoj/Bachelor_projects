package cz.muni.fi.pb162.project.geometry;

import cz.muni.fi.pb162.project.exception.MissingVerticesException;
import cz.muni.fi.pb162.project.utils.SimpleMath;


/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public abstract class SimplePolygon implements Polygon {

    /**
     *
     * @param coordinates - method checks if coordinates are not null
     */
    public SimplePolygon(Vertex2D[] coordinates) {
        if (coordinates == null) {
            throw new IllegalArgumentException("Parameter coordinates is null");
        }
        if (coordinates.length < 3){
            throw new MissingVerticesException("Less than three vertices");
        }
        for (Vertex2D c : coordinates) {
            if (c == null) {
                throw new IllegalArgumentException("null coordinate");
            }
        }
    }

    public double getHeight() {

        return SimpleMath.maxY(this) - SimpleMath.minY(this);
    }

    public double getWidth() {
        return SimpleMath.maxX(this) - SimpleMath.minX(this);
    }

    /**
     *
     * @param index vertex index, not negative number
     * @return modulo from index / number of coordinates
     */
    public abstract Vertex2D getVertex(int index);

    /**
     *
     * @return number of coordinates
     */
    public abstract int getNumVertices();

    /**
     *
     * @return information about polygon
     */
    public String toString() {
        String output = "Polygon: vertices =";
        for (int i = 0; i < getNumVertices(); i++) {

            output += (" "+getVertex(i));
        }
        return output;
    }
}
