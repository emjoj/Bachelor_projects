package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public enum Color { RED, BLUE, YELLOW, BLACK,WHITE, ORANGE,GREEN;

    /**
     *
     * @return name of coler with small letters
     */
    public String toString(){
        return this.name().toLowerCase();


    }
}


