package cz.muni.fi.pb162.project.geometry;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class Triangle extends ArrayPolygon {


        private final Triangle[] triangles = new Triangle[3];
        private static final double DELTA = 0.001;

        /**
         * constructor with initialization of triangle attributes
         *
         * @param v1 first coordinate of triangle
         * @param v2 second coordinate of triangle
         * @param v3 third coordinate of triangle
         */
        public Triangle(Vertex2D v1, Vertex2D v2, Vertex2D v3) {
            super(new Vertex2D[]{v1,v2,v3});

        }

        /**
         * @param v1    first coordinate of triangle
         * @param v2    second coordinate of triangle
         * @param v3    third coordinate of triangle
         * @param depth number of triangle division
         */
        public Triangle(Vertex2D v1, Vertex2D v2, Vertex2D v3, int depth) {

            this(v1, v2, v3);
            this.divide(depth);
        }



        private boolean inInRange(int index) {
            return !(index < 0 || index > 2);
        }

        /**
         * method finds out if subtriangle exist
         *
         * @param index represents the order of subtriangle
         * @return coordinates of triangle
         */

        public Triangle getSubTriangle(int index) {
            if (!inInRange(index) || !isDivided()) {
                return null;
            }
            return triangles[index];
        }

        /**
         * finds out if subtriangles exist
         *
         * @return true if they exist, false if they do not exist
         */
        public boolean isDivided() {
            for (int i = 0; i <= 2; i++) {
                if (this.triangles[i] == null) {
                    return false;
                }
            }
            return true;

        }

        /**
         * create subtriangles and their coordinates
         *
         * @return false if subtriangles were already
         * divided and true if they are divided after calling a method
         */
        public boolean divide() {

            if (this.isDivided()) {
                return false;
            }

            triangles[0] = new Triangle(getVertex(0),
                    getVertex(1).createMiddle(getVertex(0)), getVertex(2).createMiddle(getVertex(0)));

            triangles[1] = new Triangle(getVertex(2).createMiddle(getVertex(0)),
                    getVertex(1).createMiddle(getVertex(2)), getVertex(2));

            triangles[2] = new Triangle(getVertex(0).createMiddle(getVertex(1)),
                    getVertex(1), getVertex(1).createMiddle(getVertex(2)));

            return true;
        }

        /**
         * @return true if triangle is equilateral and vice versa
         */
        public boolean isEquilateral() {

            double d1 = getVertex(0).distance(getVertex(1));
            double d2 = getVertex(0).distance(getVertex(2));
            double d3 = getVertex(1).distance(getVertex(2));

            if ((java.lang.Math.abs(d1 - d2) < DELTA && java.lang.Math.abs(d1 - d3) < DELTA)) {
                return true;

            }
            return false;

        }

        /**
         * @param depth presents number of triangle division
         * @return false if division is not possible or true if division run correctly
         */
        public boolean divide(int depth) {
            if (depth <= 0) {
                return false;
            }

            if (!isDivided()) {
                divide();
            }

            depth--;

            triangles[0].divide(depth);
            triangles[1].divide(depth);
            triangles[2].divide(depth);

            return true;
        }


}

