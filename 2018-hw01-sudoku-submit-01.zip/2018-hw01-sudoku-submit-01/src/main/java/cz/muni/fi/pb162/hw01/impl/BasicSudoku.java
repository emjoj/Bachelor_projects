package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.Cell;
import cz.muni.fi.pb162.hw01.Sudoku;
import cz.muni.fi.pb162.hw01.helper.SudokuChecker;

import static cz.muni.fi.pb162.hw01.helper.ArrayUtils.singleElement;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class BasicSudoku implements Sudoku {

    private Cell[][] board;
    private Cell[] elements;

    /**
     * sets attributes
     * @param board 2D array of Sudoku
     * @param elements are available values in game
     */
    public BasicSudoku(Cell[][]board, Cell[]elements){
        this.board = board;
        this.elements = elements;

    }

    public int getSize(){
        return elements.length;

    }

    public int getBlockSize(){
        return (int)Math.sqrt(getSize());
    }

    /**
     *
     * @return used values in Sudoku
     */
    public Cell[] availableValues(){
        return elements;

    }

    /**
     *
     * @param column cell column index
     * @param row    cell row index
     * @return value of the Cell, if Cell is empty return null
     */
    public Cell getCell(int column, int row){
        if (board[column][row] == null){
            return null;
        }
        return board[column][row];
    }

    /**
     *
     * @param column column index
     * @return array of values in particular column
     */
    public Cell[] getColumn(int column){

        return board[column];
    }

    /**
     *
     * @param row row index
     * @return array of values in particular row
     */
    public Cell[] getRow(int row){
        Cell[] output = new Cell[getSize()];

        for(int i = 0; i < getSize(); i++){
            output[i] = board[i][row];
        }
        return output;
    }

    /**
     *
     * @param globalColumn block column index
     * @param globalRow    block rox index
     * @return cells in the block from left to right, from top to bottom
     */
    public Cell[] getBlock(int globalColumn, int globalRow){

        Cell[] block = new Cell[getBlockSize()*getBlockSize()];
        int index = 0;
        for(int row = globalRow * getBlockSize() ; row < globalRow * getBlockSize() + getBlockSize(); row++){
            for(int column = globalColumn * getBlockSize();
                column < globalColumn * getBlockSize()+ getBlockSize();column++){

                block[index] = board[column][row];
                index++;
            }
        }
        return block;

    }

    /**
     *
     * @param column column index
     * @param row    row index
     * @return array containing all cells which can be inserted into chosen position
     */
    public Cell[] getOptions(int column, int row){

        if (getCell(column,row)!=null){
            return new Cell[0];
        }
        int index = 0;
        SudokuChecker sudokuChecker = new SudokuChecker(this);
        Cell[] options = new Cell[getSize()];

        for(int i =0; i < getSize(); i++){
            if(sudokuChecker.canInsert(column,row,elements[i])){
                options[index] = elements[i];
                index++;
            }
        }
        return options;
    }

    /**
     *
     * @param column column index
     * @param row    row index
     * @return cell which can be inserted into (empty) position, null otherwise
     */
    public Cell getHint(int column, int row){
        return singleElement(getOptions(column,row));

    }

    /**
     *
     * @return hints for every position in the sudoku
     */
    public Cell[][] getAllHints() {
        Cell[][] hints = new Cell[getSize()][getSize()];
        for (int row = 0; row < getSize(); row++) {
            for (int column = 0; column < getSize(); column++) {
                hints[column][row] = getHint(column, row);
            }
        }
        return hints;
    }

    /**
     *
     * @param column column index
     * @param row    row index
     * @param c      element to be put
     * @return true, if cell was inserted successfully, false if some sudoku rule was violated
     */
    public boolean putElement(int column, int row, Cell c){
        SudokuChecker sudoku = new SudokuChecker(this);
        if(sudoku.canInsert(column,row,c)){
            board[column][row] = c;
            return true;
        }else return false;

    }
}
