package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.Cell;
import cz.muni.fi.pb162.hw01.helper.ArrayUtils;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class DiagonalSudokuChecker {

    private DiagonalSudoku sudoku;

    /**
     * sets attribute
     * @param sudoku type of game
     */
    public DiagonalSudokuChecker(DiagonalSudoku sudoku){
        this.sudoku = sudoku;
    }

    /**
     *
     * @param column index
     * @param row index
     * @return if the cell is in Diagonal1
     */
    public boolean isDiagonal1(int column, int row) {

        return (column == row);
    }

    /**
     *
     * @param column index
     * @param row index
     * @return if the cell is in Diagonal2
     */
    public boolean isDiagonal2(int column, int row) {

        return (column + row == sudoku.getSize() - 1);
    }

    /**
     *
     * @return array of values in Diagonal1
     */
    public Cell[] diagonal1Cells() {
        Cell[] diagonal1 = new Cell[sudoku.getSize()];

        for (int i = 0; i < sudoku.getSize(); i++) {
            diagonal1[i] = sudoku.getCell(i, i);
        }
        return diagonal1;
    }

    /**
     *
     * @return array of values in Diagonal2
     */
    public Cell[] diagonal2Cells() {
        Cell[] diagonal2 = new Cell[sudoku.getSize()];

        for (int i = 0; i < sudoku.getSize(); i++) {
            diagonal2[i] = sudoku.getCell(i, sudoku.getSize() - i -1);
        }
        return diagonal2;
    }

    /**
     *
     * @param col index
     * @param row index
     * @param c value of cell
     * @return if cell can be put in Diagonal1
     */
    public boolean isDiagonal1Valid(int col, int row,Cell c) {

        return !ArrayUtils.contains(diagonal1Cells(), c);
    }

    /**
     *
     * @param col index
     * @param row index
     * @param c value of cell
     * @return if cell can be put in Diagonal2
     */
        public boolean isDiagonal2Valid(int col, int row,Cell c){

            return !ArrayUtils.contains(diagonal2Cells(), c);
        }
    }



