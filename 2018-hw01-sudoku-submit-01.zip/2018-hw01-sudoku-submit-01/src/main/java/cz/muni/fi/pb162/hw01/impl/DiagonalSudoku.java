package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.Cell;
import cz.muni.fi.pb162.hw01.Sudoku;
import cz.muni.fi.pb162.hw01.helper.ArrayUtils;
import cz.muni.fi.pb162.hw01.helper.SudokuChecker;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class DiagonalSudoku extends BasicSudoku implements Sudoku {

    private Cell[][] board;

    /**
     *
     * @param board is 2D array of Sudoku game
     * @param elements are available values in Sudoku
     */
    public DiagonalSudoku(Cell[][]board, Cell[]elements){

        super(board,elements);
        this.board = board;
    }

    @Override
    public Cell[] getOptions(int column, int row) {

        DiagonalSudokuChecker diaSudokuChecker = new DiagonalSudokuChecker(this);
        Cell[] basicSOptions = super.getOptions(column,row);
        Cell[] diagonalSOptions = new Cell[getSize()];

        if (getCell(column, row) != null) return new Cell[0];


        if(diaSudokuChecker.isDiagonal1(column,row)){
            diagonalSOptions = ArrayUtils.difference(basicSOptions, diaSudokuChecker.diagonal1Cells());

        } else if(diaSudokuChecker.isDiagonal2(column,row)){

            diagonalSOptions = ArrayUtils.difference(basicSOptions, diaSudokuChecker.diagonal2Cells());

        } else if((!diaSudokuChecker.isDiagonal1(column,row)) || (!diaSudokuChecker.isDiagonal2(column,row))){

            return basicSOptions;
        }

        return diagonalSOptions;

    }


    @Override
    public boolean putElement(int column, int row, Cell c) {

        DiagonalSudokuChecker diaChecker = new DiagonalSudokuChecker(this);
        SudokuChecker sudoku = new SudokuChecker(this);

            if(sudoku.canInsert(column,row,c)){

                if ((diaChecker.isDiagonal1Valid(column, row, c) && diaChecker.isDiagonal1(column,row))
                        || (diaChecker.isDiagonal2Valid(column, row, c)&& diaChecker.isDiagonal2(column,row))) {
                    board[column][row] = c ;
                    return true;
            }
        }
        return super.putElement(column,row,c);
    }

}

