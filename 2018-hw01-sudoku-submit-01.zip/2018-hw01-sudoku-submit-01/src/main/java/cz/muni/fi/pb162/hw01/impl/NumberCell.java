package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.InfiniteCellSequence;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class NumberCell extends InfiniteCellSequence {
    private int value;

    /**
     * sets attribute value
     * @param value is value of the cell
     */
    public NumberCell(int value){

        this.value = value;
    }

    /**
     *
     * @return fitst value of the array
     */
    public InfiniteCellSequence startingValue(){

        return new NumberCell(1);
    }

    /**
     *
     * @return next value of the array
     */
    public InfiniteCellSequence nextValue(){

        return new NumberCell(this.value +1);
    }

    public String getValue(){

        return String.valueOf(value);

    }
}
