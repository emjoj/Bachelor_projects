package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.InfiniteCellSequence;

/**
 * TODO : Letter Cell type of Sudoku
 *
 * @author Ema Stefanikova
 */


public class LetterCell extends InfiniteCellSequence {
    private char value;

    /**
     * sets attribute value
     * @param value is value of the Cell
     */
    public LetterCell(char value){
        this.value = value;

    }

    /**
     *
     * @return first cell value from array
     */
    public InfiniteCellSequence startingValue(){

        return new LetterCell('A');
    }

    /**
     *
     * @return next value from array
     */
    public InfiniteCellSequence nextValue(){

        int output = (int) this.value + 1;
        return new LetterCell((char) output);
    }

    public String getValue(){
        return String.valueOf(value);

    }

}

