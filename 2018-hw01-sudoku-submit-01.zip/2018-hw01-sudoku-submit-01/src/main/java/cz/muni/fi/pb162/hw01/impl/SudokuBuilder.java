package cz.muni.fi.pb162.hw01.impl;

import cz.muni.fi.pb162.hw01.Cell;
import cz.muni.fi.pb162.hw01.InfiniteCellSequence;
import cz.muni.fi.pb162.hw01.Sudoku;


/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class SudokuBuilder {
    private boolean isDiagonal;
    private Cell[][] dimension;
    private InfiniteCellSequence cellType;
    private Cell[] elements;


    /**
     * sets attributes
     * @param size is number of cells in sudoku
     * @param cellType type of game
     */
    public SudokuBuilder(int size, InfiniteCellSequence cellType) {

        this.cellType = cellType;
        this.dimension = new Cell[size][size];
        this.elements = cellType.firstNValues(size);



    }

    /**
     * sets value in the cell
     * @param column index
     * @param row index
     * @param c value of the cell
     * @return  reference to current object
     */
    public SudokuBuilder cell(int column, int row, Cell c){
        dimension[column][row] = c;
        return this;
    }

    /**
     *
     * @param isDiagonal sets the type of game
     * @return reference to current object
     */
    public SudokuBuilder diagonal(boolean isDiagonal){
        this.isDiagonal = isDiagonal;
        return this;


    }

    /**
     *
     * @return object of the wanted type of game
     */
    public Sudoku build(){
        if (isDiagonal){
            return new DiagonalSudoku(dimension,elements);

        }else return new BasicSudoku(dimension,elements);

    }

}
