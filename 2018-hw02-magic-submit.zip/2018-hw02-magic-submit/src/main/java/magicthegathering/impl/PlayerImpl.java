package magicthegathering.impl;
import magicthegathering.game.Card;
import magicthegathering.game.CreatureCard;
import magicthegathering.game.LandCard;
import magicthegathering.game.ManaType;
import magicthegathering.game.Player;

import java.util.ArrayList;
import java.util.List;


/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class PlayerImpl implements Player {

    private final String name;
    private int life = INIT_LIVES;
    private List<Card> handCards = new ArrayList<>();
    private List<Card> tableCards = new ArrayList<>();

    /**
     * Checks if name is relevant
     * @param name of the player
     */
    public PlayerImpl(String name){

         if(name == null || name.equals("")){
             throw new IllegalArgumentException("Name is not set");
         }

         this.name = name;

    }

    @Override
    public String toString(){
        return name + "(" + life + ")";
    }

    /**
     * Get player's name.
     *
     * @return players name
     */
    public String getName(){
        return name;
    }

    /**
     * Get player's number of lives.
     *
     * @return life
     */
    public int getLife(){
        return life;
    }

    /**
     * Subtract player's lives.
     *
     * @param lives lives
     */
    public void subtractLives(int lives){
        this.life -= lives;

    }

    /**
     * Returns true, if player's lives are below or equal to 0.
     *
     * @return if a player is dead
     */
    public boolean isDead(){

        return (getLife() <=0);
    }

    /**
     * Initial cards put into player's hand. Cards from the table are removed.
     * Input parameter is copied.
     *
     * @param cards to be put into player's hand
     */
    public void initCards(List<Card> cards){

        tableCards.clear();
        handCards.addAll(cards);

    }

    /**
     * Get player's cards in hand.
     *
     * @return player's cards in hand
     */
    public List<Card> getCardsInHand(){
        return handCards;
    }

    /**
     * Get player's cards on the table.
     *
     * @return player's cards on the table
     */

    public List<Card> getCardsOnTable(){
        return tableCards;

    }

    /**
     * Get player's lands on the table.
     *
     * @return player's lands on the table
     */
    public List<LandCard> getLandsOnTable(){
        List<LandCard> landCards= new ArrayList<>();

        for(Card c : tableCards) {
            if (instanceOfLand(c)) {
                landCards.add((LandCard)c);
            }
        }

        return landCards;
    }

    private boolean instanceOfLand(Card c ){
        return ( c instanceof LandCard);
    }

    private boolean instanceOfCreature(Card c){
        return (c instanceof CreatureCard);
    }

    /**
     * Get player's creatures on the table.
     *
     * @return player's creatures on the table
     */
    public List<CreatureCard> getCreaturesOnTable(){
        List<CreatureCard> creatureCards = new ArrayList<>();
        for(Card c : tableCards){
            if(instanceOfCreature(c)){
                creatureCards.add((CreatureCard)c);
            }
        }
        return creatureCards;
    }

    /**
     * Get player's lands in hand.
     *
     * @return player's lands in hand
     */
    public List<LandCard> getLandsInHand(){
        List<LandCard> landCards = new ArrayList<>();

        for(Card c : handCards){
            if(instanceOfLand(c)){
                landCards.add((LandCard)c);
            }
        }
        return landCards;

    }

    /**
     * Get player's creatures in hand.
     *
     * @return player's creatures in hand
     */
    public List<CreatureCard> getCreaturesInHand(){
        List<CreatureCard> creatureCards = new ArrayList<>();

        for(Card c : handCards){
            if(instanceOfCreature(c)){
                creatureCards.add((CreatureCard)c);
            }
        }
        return creatureCards;
    }

    /**
     * Untap all cards on the table.
     */
    public void untapAllCards(){
        for (Card c : tableCards){
            c.untap();
        }
    }

    /**
     * Unset summoning sickness of all creatures.
     */
    public void prepareAllCreatures(){
        for(Card c :tableCards){
            if(instanceOfCreature(c)){
                ((CreatureCard) c).unsetSummoningSickness();
            }
        }
    }

    /**
     * Put a land from hand on table.
     *
     * @param landCard land to be put on the table
     * @return true if succeeded, false if land is not in player's hand or already on the table
     */
    public boolean putLandOnTable(LandCard landCard){
        if((!handCards.contains(landCard))){
            return false;
        }
        tableCards.add(landCard);
        landCard.putOnTable();
        handCards.remove(landCard);

        return true;

    }


    /**
     * Put a creature from hand to table. Taps lands for mana needed to summon a creature.
     *
     * @param creatureCard creature card to be put on the table
     * @return true if succeeded, false if creature is not in player's hand,
     * already on the table, or player does not have enough mana
     */
    public boolean putCreatureOnTable(CreatureCard creatureCard){


            if(handCards.contains(creatureCard)){
                if(hasManaForCreature(creatureCard) && !(tableCards.contains(creatureCard))){
                    creatureCard.putOnTable();
                    creatureCard.setSummoningSickness();
                        tableCards.add(creatureCard);

                        handCards.remove(creatureCard);
                        tapManaForCreature(creatureCard);
                        return true;
                    }
                }


        return  false;

    }

    /**
     * Checks whether user has enough mana to summon the input creature.
     *
     * @param creature creature to be checked
     * @return true if has enough mana, false otherwise
     */


    public boolean hasManaForCreature(CreatureCard creature){

        int mana = creature.getTotalCost();
        for(int index = 0;index <5; index ++){

            if(calculateCostOfCreature(creature)[index] <= calculateUntappedLands()[index]){
                mana -= calculateCostOfCreature(creature)[index];
            }
        }
        return(mana == 0);
        }


    /**
     * Calculates how many untapped lands has player on the table.
     *
     * @return array of integers, where every number represents how many untapped lands the player has in the following
     * (ordinal) order: WHITE, RED, GREEN, BLUE, BLACK. You can use {@link ManaType#ordinal()} method.
     */
    public int[] calculateUntappedLands() {

        List<LandCard> landCards = new ArrayList<>(getLandsOnTable());

        int[] untappedLands = new int[5];

        for (LandCard l : landCards) {
            if (!l.isTapped()) {
                if (l.getManaType() == ManaType.WHITE) {
                    untappedLands[0] += 1;
                } else if (l.getManaType() == ManaType.RED) {
                    untappedLands[1] += 1;
                } else if (l.getManaType() == ManaType.GREEN) {
                    untappedLands[2] += 1;
                } else if (l.getManaType() == ManaType.BLUE) {
                    untappedLands[3] += 1;
                } else if (l.getManaType() == ManaType.BLACK) {
                    untappedLands[4] += 1;
                }
            }

        }return untappedLands;
    }

    private int[] calculateCostOfCreature(CreatureCard creature ) {

        int[] cost = new int[5];
        int index = 0;
        for (ManaType m : ManaType.values()) {
            cost[index] = creature.getSpecialCost(m);
            index += 1;

        }
        return cost;
    }

    /**
     * Taps the lands needed for summoning a creature.
     *
     * @param creature creature which price needs to be paid
     */
    public void tapManaForCreature(CreatureCard creature){

        int[] costCreature = calculateCostOfCreature(creature).clone();
        int manaType = -1;

        for (ManaType m : ManaType.values()) {
            manaType +=1;

            for(int index = 0; index < getLandsOnTable().size();index++){
               if(( getLandsOnTable().get(index).getManaType() == m) && (costCreature[manaType] > 0)){
                   getLandsOnTable().get(index).tap();
                   costCreature[manaType] =-1;
               }
            }
        }
    }

    /**
     * Removes creature from the game.
     *
     * @param creature creature to be removed.
     */
    public void destroyCreature(CreatureCard creature){
        tableCards.remove(creature);
    }
}

