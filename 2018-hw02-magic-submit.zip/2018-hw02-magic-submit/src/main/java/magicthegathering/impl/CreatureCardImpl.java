package magicthegathering.impl;
import magicthegathering.game.AbstractCard;
import magicthegathering.game.CreatureCard;
import magicthegathering.game.ManaType;

import java.util.List;
import java.util.Objects;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class CreatureCardImpl extends AbstractCard implements CreatureCard {

    private String name;
    private List<ManaType> cost;
    private int power;
    private int toughness;
    private boolean summoningSickness = true;

    /**
     * Check if inputs are relevant
     * @param name of creature
     * @param cost how many mana needed
     * @param power of creature
     * @param toughness of creature
     */
    public CreatureCardImpl(String name, List<ManaType> cost, int power, int toughness){

        if ((name==null) || (name.equals(""))){

            throw new IllegalArgumentException("Name is not set");
        }

        if(cost == null){

            throw new IllegalArgumentException("Creature cost cannot be null");
        }


        if ((power < 0)|| (toughness <= 0)){

            throw new IllegalArgumentException("Power or toughness is a negative number");
        }

        this.name = name;
        this.cost = cost;
        this.power = power;
        this.toughness = toughness;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CreatureCardImpl that = (CreatureCardImpl) o;
        return power == that.power &&
                toughness == that.toughness &&
                Objects.equals(name, that.name) &&
                Objects.equals(cost, that.cost);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, cost, power, toughness);
    }

    /**
     * Get the sum of costs for all the mana types.
     *
     * @return total cost
     */
    public int getTotalCost(){
        return cost.size();
    }

    /**
     * Get cost for specific mana type.
     * If the creature does not use a certain mana type, 0 is returned.
     *
     * @param mana mana
     * @return cost for given mana type
     */
    public int getSpecialCost(ManaType mana){
        int output = 0;
        for (ManaType m : cost){
            if(m == mana){
                output += 1;
            }
        }
        return output;
    }

    /**
     * Get name of the creature.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Get power of the creature. This is the value user for attack.
     *
     * @return power
     */
    public int getPower(){
        return power;
    }

    /**
     * Get toughness of the creature. This value is used for defense.
     *
     * @return toughness
     */
    public int getToughness(){
        return toughness;
    }

    /**
     * Check, whether the creature has summoning sickness.
     *
     * @return summoning sickness
     */
    public boolean hasSummoningSickness(){
        return summoningSickness;

    }

    /**
     * Set summoning sickness. This value is set after the creature is first put on table.
     */

    public void setSummoningSickness(){
        summoningSickness = true;
        }


    /**
     * Unset summoning sickness so that the creature can attack now.
     */
    public void unsetSummoningSickness(){
        summoningSickness = false;

    }

    @Override
    public String toString(){
        String string = getName() + " " + cost + " " + getPower() + " / " + getToughness();
        if(!this.hasSummoningSickness()){
            string += " can attack";
        }
        if(this.isTapped()){
            string += " TAPPED";
        }
        return string;

    }
}

