package magicthegathering.impl;

import magicthegathering.game.CreatureCard;
import magicthegathering.game.Game;
import magicthegathering.game.Generator;
import magicthegathering.game.Player;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class GameImpl implements Game {

    private Player player1;
    private Player player2;
    private Player currentPlayer;

    /**
     *Checks if inputs are relevant and not null
     * @param player1 first player
     * @param player2 second player
     */
    public GameImpl(Player player1, Player player2){
        if(player1 == null || player2 == null){
            throw new IllegalArgumentException("Player cannot be null");
        }


        this.player1 = player1;
        this.player2 = player2;

        this.currentPlayer = player1;



    }

    /**
     * Generates player's cards.
     */
    public void initGame() {
        this.player1.initCards(Generator.generateCards());
        this.player2.initCards(Generator.generateCards());

    }
    /**
     * Set (pick) next player.
     */

    public void changePlayer(){

        if(currentPlayer.equals(player1)){
            currentPlayer = player2;

        }else currentPlayer = player1;

        }

    /**
     * Prepare player for turn: untap all the cards and unset summoning sickness on creatures.
     */
    public void prepareCurrentPlayerForTurn(){

        currentPlayer.untapAllCards();

        for(CreatureCard c : currentPlayer.getCreaturesOnTable()) {
            c.unsetSummoningSickness();
        }

        }
    /**
     * Get current player.
     *
     * @return current player
     */
    public Player getCurrentPlayer(){
        return currentPlayer;


        }

    /**
     * Get the other player.
     *
     * @return other player
     */
    public Player getSecondPlayer() {
        if (currentPlayer.equals(player1)) {
            return player2;
        }
        return player1;
    }

        /**
         * Perform attack from current player to the second player.
         * All attacking creatures are tapped.
         *
         * @param creatures creatures which are going to attack
         */
        public void performAttack (List < CreatureCard > creatures) {

            if(isCreaturesAttackValid(creatures)){
                for(CreatureCard c : creatures){
                    c.tap();
                }
            }

        }


    /**
     * Checks whether creatures which are going to attack do not break any rules.
     *
     * @param attackingCreatures list of attacking creatures
     * @return true if all creatures are able to attack, false if any creature has summoning sickness,
     * is tapped, does not belong to the current player or the list contains duplicate creatures
     */
    public boolean isCreaturesAttackValid( List<CreatureCard> attackingCreatures) {
        for (CreatureCard c : attackingCreatures) {

            if ((c.hasSummoningSickness()) || (c.isTapped())) {
                return false;
            }else if
                    (!currentPlayer.getCreaturesOnTable().contains(c)) {
                return false;

            }

            Set<CreatureCard> setCreatures = new HashSet<>(attackingCreatures);
            if (setCreatures.size() != attackingCreatures.size()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Checks whether blocking does not break any rules.
     * Null elements represent that creature is not going to be blocked.
     *
     * @param attackingCreatures list of attacking creatures
     * @param blockingCreatures  list of blocking creatures
     * @return false if lists have different length, contains duplicates elements excluding null,
     * or attacking/blocking creatures do not belong to the current/second player
     * or blocking creature is tapped
     */


    public boolean isCreaturesBlockValid(List<CreatureCard> attackingCreatures, List<CreatureCard> blockingCreatures) {
        List<CreatureCard> withoutNull = new ArrayList<>(blockingCreatures);
        withoutNull.removeAll(Collections.singleton(null));

        Set<CreatureCard> blockSet = new HashSet<>(withoutNull);
        Set<CreatureCard> attackSet = new HashSet<>(attackingCreatures);

        if (withoutNull.size() != blockSet.size()) {
            return false;
        } else if (attackSet.size() != attackingCreatures.size()) {
            return false;
        } else if (attackingCreatures.size() != blockingCreatures.size()) {
            return false;
        }

        if(!blockingCreatures.isEmpty()){
            for (int i = 0; i < attackingCreatures.size(); i++) {

                if (blockingCreatures.get(i) != null) {
                    if (!getSecondPlayer().getCreaturesOnTable().contains(blockingCreatures.get(i))) {
                        return false;
                    }else if(blockingCreatures.get(i).isTapped()){
                        return false;
                    }
                } else if (!currentPlayer.getCreaturesOnTable().contains(attackingCreatures.get(i))) {
                    return false;
                }
            }
        }
        return true;
    }


    /**
     * Evaluates the block, damage to the creatures, their removal, damage to the player.
     *
     * @param attackingCreatures list of attacking creatures
     * @param blockingCreatures  list of blocking creatures
     */
    public void performBlockAndDamage( List<CreatureCard> attackingCreatures,  List<CreatureCard> blockingCreatures){

        for(int i = 0; i < attackingCreatures.size();i++){
            if(blockingCreatures.get(i)==null){
                getSecondPlayer().subtractLives(attackingCreatures.get(i).getPower());

            }else if ( attackingCreatures.get(i).getToughness() < blockingCreatures.get(i).getPower()){
                currentPlayer.destroyCreature(attackingCreatures.get(i));
            }else if (attackingCreatures.get(i).getPower() > blockingCreatures.get(i).getToughness()){
                getSecondPlayer().destroyCreature(blockingCreatures.get(i));
            }else if ( attackingCreatures.get(i).getPower() == blockingCreatures.get(i).getToughness()){
                getSecondPlayer().destroyCreature(blockingCreatures.get(i));
            }else if((blockingCreatures.get(i).getPower() == attackingCreatures.get(i).getToughness())) {
                currentPlayer.destroyCreature(attackingCreatures.get(i));
            }
            }
        }


}


