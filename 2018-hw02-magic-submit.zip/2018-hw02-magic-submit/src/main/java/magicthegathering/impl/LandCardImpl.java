package magicthegathering.impl;
import magicthegathering.game.AbstractCard;
import magicthegathering.game.LandCard;
import magicthegathering.game.LandCardType;
import magicthegathering.game.ManaType;

import java.util.Objects;

/**
 * TODO : create javadoc
 *
 * @author Ema Stefanikova
 */

public class LandCardImpl extends AbstractCard implements LandCard {

    private final LandCardType landType;
    private ManaType manaType;


    /**
     * Checks if input is relevant
     * @param landType type of land
     */
    public LandCardImpl(LandCardType landType){

        if (landType == null){
            throw new IllegalArgumentException("Land type cannot be null");
        }
        this.landType = landType;

    }




    @Override
    public String toString(){
        return "Land " + landType.name().toLowerCase() + ", " + getManaType();

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LandCardImpl landCard = (LandCardImpl) o;
        return landType == landCard.landType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(landType);
    }

    /**
     * Returns type of the given land.
     *
     * @return land type
     */
    public LandCardType getLandType(){
        return landType;
    }

    /**
     * Returns mana for the given land type.
     * If none of the types fit, it returns null.
     *
     * @return mana type
     */
    public ManaType getManaType(){

        if(landType == LandCardType.PLAINS){
            manaType = ManaType.WHITE;
        }else if(landType == LandCardType.MOUNTAIN){
            manaType = ManaType.RED;
        }else if(landType == LandCardType.FOREST){
            manaType = ManaType.GREEN;
        }else if(landType == LandCardType.ISLAND){
            manaType = ManaType.BLUE;
        }else if(landType == LandCardType.SWAMP) {
            manaType = ManaType.BLACK;
        }else return null;


        return manaType;
    }
}
