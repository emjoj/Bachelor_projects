package magicthegathering.game;

/**
 * Type of land card.
 *
 * @author Zuzana Wolfova, Patrik Majerčík
 */
public enum LandCardType {
    PLAINS, MOUNTAIN, FOREST, ISLAND, SWAMP,

}
