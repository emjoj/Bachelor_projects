package magicthegathering.game;

/**
 * Type of mana type, related to given land type.
 *
 * @author Zuzana Wolfova
 */
public enum ManaType {
    WHITE, RED, GREEN, BLUE, BLACK,
}
